﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InicioPartida
{
    public partial class Form2 : Form
    {
        Socket clienteSocket;
        private Random random = new Random();
        public Form2(Socket sock)
        {
            clienteSocket = sock;
            InitializeComponent();
        }

        private void f2_Load(object sender, EventArgs e)
        {
            Tablero.BackgroundImageLayout = ImageLayout.Stretch;
            labelnumero.Text = "?";
            Tablero.Visible = true;

        }

        private void tirardado_Click(object sender, EventArgs e)
        {
            int dadoResultado = random.Next(1, 7);

            // Actualizar el texto del label
            var lblDadoResultado = this.Controls.Find("lblDadoResultado", true).FirstOrDefault() as Label;
            if (lblDadoResultado != null)
            {
                lblDadoResultado.Text = $"Resultado: {dadoResultado}";
            }

            // Lógica adicional del juego (como pasar turno, mover ficha, etc.)
            MessageBox.Show($"Has tirado el dado y salió: {dadoResultado}");

        }

        private void labelnumero_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



