# Proyecto_SO
Link to the video: https://drive.google.com/file/d/1wHYutVwZkYQWGuHWgta8j5e4ws8Kk0gm/view?usp=drive_link
